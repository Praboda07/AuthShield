package Authshield;

import java.io.*;
import java.net.InetAddress;
import java.net.Socket;

public class Authclient {

    public static void main(String[] args) throws IOException {

        System.out.println("Client starting...");

        InetAddress ipAddress = InetAddress.getLocalHost();

        Socket authsocket = new Socket(ipAddress, 6363);

        System.out.println("Server connected.");

        BufferedReader keyboard = new BufferedReader(
                new InputStreamReader(System.in));

        BufferedReader input = new BufferedReader(
                new InputStreamReader(authsocket.getInputStream()));

        PrintWriter output = new PrintWriter(
                authsocket.getOutputStream(), true);

        for (int i = 0; i < 3; i++) {

            System.out.println("Enter Your User Name or Email:");
            String user_name = keyboard.readLine();

            System.out.println("Please Enter the Password:");
            String passwords = keyboard.readLine();

            output.println(user_name);
            output.println(passwords);

            String response = input.readLine();

            System.out.println("Checking Login Requirement...");
            System.out.println(response);

            if (response == null
                    || response.equals("Login Successfully")
                    || response.equals("Temporarily Blocked")) {
                break;
            }
        }

        authsocket.close();
        
    }
}