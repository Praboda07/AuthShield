package Authshield;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class AuthServer {

    public static void main(String[] args) throws IOException {
    	String user_name="Admin";
    	String password="1234";
        ServerSocket authss = new ServerSocket(6363);

        System.out.println("Welcome to AuthShield.");
        System.out.println("AuthShield server started...");
        System.out.println("Waiting for client...");

        Socket authsocket = authss.accept();
        System.out.println("Client connected.");

        BufferedReader input = new BufferedReader(
                new InputStreamReader(authsocket.getInputStream()));

        PrintWriter output = new PrintWriter(
                authsocket.getOutputStream(), true);

        int wrong_attempt = 0;

        for (int i = 0; i < 3; i++) {

            String user_names = input.readLine();
            String passwords = input.readLine();

            if (user_names == null || passwords == null) {
                break;
            }

            System.out.println("Received username: " + user_names);

            if (user_names.equals("Admin")
                    && passwords.equals("1234")) {

                output.println("Login Successfully");
                System.out.println("Login successful.");
                break;

            } else {

                wrong_attempt++;

                System.out.println("Login failed. Attempt: "
                        + wrong_attempt);

                if (wrong_attempt >= 3) {
                    output.println("Temporarily Blocked");
                    System.out.println("Client temporarily blocked.");
                } else {
                    output.println("Login Failed");
                }
            }
        }

        authsocket.close();
        authss.close();

        System.out.println("Server closed.");
    }
}